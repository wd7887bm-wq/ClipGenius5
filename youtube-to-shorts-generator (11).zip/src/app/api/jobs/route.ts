import { NextRequest, NextResponse } from "next/server";
import { v4 as uuidv4 } from "uuid";
import { spawn, execSync, spawnSync } from "child_process";
import path from "path";
import fs from "fs";
import { ensureSchema } from "@/db/ensure-schema";
import { checkRateLimit, getClientIdentifier } from "@/lib/rate-limiter";
import {
  canAcceptNewJob,
  incrementWorkers,
  decrementWorkers,
  getSystemStats,
} from "@/lib/system-health";

export const dynamic = "force-dynamic";

let depsReady = false;

function hasTool(name: string): boolean {
  try {
    const r = spawnSync("which", [name], { timeout: 5000, stdio: "pipe" });
    return r.status === 0 && r.stdout.toString().trim().length > 0;
  } catch {
    return false;
  }
}

function forceInstallDeps(): boolean {
  if (depsReady) return true;

  try {
    if (!hasTool("ffmpeg")) {
      console.log("[Setup] Installing ffmpeg...");
      execSync("sudo apt-get update -qq 2>/dev/null; sudo apt-get install -y -qq ffmpeg 2>/dev/null || apt-get install -y -qq ffmpeg 2>/dev/null || true", {
        timeout: 120000, shell: "/bin/bash", stdio: "pipe",
      });
    }

    if (!hasTool("yt-dlp")) {
      console.log("[Setup] Installing Python packages...");
      execSync("pip3 install --break-system-packages yt-dlp psycopg2-binary faster-whisper 2>/dev/null || pip3 install yt-dlp psycopg2-binary faster-whisper 2>/dev/null || true", {
        timeout: 180000, shell: "/bin/bash", stdio: "pipe",
      });
    }

    // Final check
    const ok = hasTool("yt-dlp") && hasTool("ffmpeg");
    if (ok) {
      depsReady = true;
      console.log("[Setup] All tools ready");
    } else {
      console.error("[Setup] Tools still missing after install attempt");
    }
    return ok;
  } catch (e) {
    console.error("[Setup] Install error:", e);
    return false;
  }
}

// Auto-cleanup every 5 min
setInterval(() => {
  try {
    const clipsDir = path.join(process.cwd(), "public", "clips");
    if (!fs.existsSync(clipsDir)) return;
    const now = Date.now();
    for (const entry of fs.readdirSync(clipsDir)) {
      const p = path.join(clipsDir, entry);
      try {
        if (now - fs.statSync(p).mtimeMs > 3600000) {
          fs.rmSync(p, { recursive: true, force: true });
        }
      } catch {}
    }
  } catch {}
}, 300000);

export async function POST(req: NextRequest) {
  try {
    // Rate limit
    const clientId = getClientIdentifier(req);
    const rl = checkRateLimit(clientId, 5, 3600000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: "Rate limit exceeded", details: "Max 5 videos per hour." },
        { status: 429 }
      );
    }

    // Parse
    let body;
    try { body = await req.json(); } catch {
      return NextResponse.json({ error: "Invalid request" }, { status: 400 });
    }
    const { url, captionStyle = "oneword" } = body;
    if (!url || typeof url !== "string") {
      return NextResponse.json({ error: "YouTube URL required" }, { status: 400 });
    }
    const ytRegex = /^(https?:\/\/)?(www\.)?(youtube\.com\/(watch\?v=|shorts\/|embed\/)|youtu\.be\/)/;
    if (!ytRegex.test(url)) {
      return NextResponse.json({ error: "Invalid YouTube URL" }, { status: 400 });
    }

    // System health
    if (!canAcceptNewJob()) {
      return NextResponse.json({ error: "Server busy. Try again soon." }, { status: 503 });
    }

    // DB
    const dbOk = await ensureSchema();
    if (!dbOk) {
      return NextResponse.json({ error: "Database error" }, { status: 503 });
    }

    // Install deps
    const depsOk = forceInstallDeps();
    if (!depsOk) {
      return NextResponse.json(
        { error: "Server is setting up. Please try again in 30 seconds." },
        { status: 503 }
      );
    }

    // Create job
    const { getDb } = await import("@/db");
    const { jobs } = await import("@/db/schema");
    const db = getDb();

    const jobId = uuidv4();
    const outputDir = path.join(process.cwd(), "public", "clips", jobId);
    fs.mkdirSync(outputDir, { recursive: true });

    await db.insert(jobs).values({
      id: jobId,
      youtubeUrl: url,
      captionStyle,
      status: "pending",
      progress: 0,
      progressMessage: "Starting...",
      expiresAt: new Date(Date.now() + 3600000),
    });

    // Start Python - use shell to ensure PATH is correct
    const scriptPath = path.join(process.cwd(), "scripts", "process_video.py");

    incrementWorkers();

    const child = spawn("/bin/bash", ["-c",
      `export PATH="/usr/local/bin:/usr/bin:$PATH" && python3 "${scriptPath}" "${jobId}" "${url}" "${outputDir}" "${captionStyle}"`
    ], {
      detached: true,
      stdio: ["ignore", "pipe", "pipe"],
      cwd: process.cwd(),
      env: {
        ...process.env,
        PATH: "/usr/local/bin:/usr/bin:" + (process.env.PATH || ""),
        DATABASE_URL: process.env.DATABASE_URL,
      },
    });

    child.stdout?.on("data", (d) => console.log(`[${jobId.slice(0, 8)}] ${d.toString().trim()}`));
    child.stderr?.on("data", (d) => console.error(`[${jobId.slice(0, 8)}] ${d.toString().trim()}`));
    child.on("exit", (code) => {
      decrementWorkers();
      if (code !== 0) {
        console.error(`[${jobId.slice(0, 8)}] Process exited with code ${code}`);
      }
    });
    child.on("error", (e) => {
      decrementWorkers();
      console.error(`[${jobId.slice(0, 8)}] Spawn error:`, e);
    });
    child.unref();

    return NextResponse.json({ jobId, status: "pending" });
  } catch (error) {
    console.error("[API]", error);
    return NextResponse.json(
      { error: "Server error", details: error instanceof Error ? error.message : "Unknown" },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({ system: getSystemStats(), depsReady });
}
