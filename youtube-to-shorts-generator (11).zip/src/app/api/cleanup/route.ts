import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { ensureSchema } from "@/db/ensure-schema";
import { eq, lt } from "drizzle-orm";

export const dynamic = "force-dynamic";

/**
 * Cleanup endpoint - removes expired jobs and their files
 * Can be called by a cron job or scheduler
 */
export async function POST() {
  try {
    await ensureSchema();

    const { getDb } = await import("@/db");
    const { jobs } = await import("@/db/schema");
    const db = getDb();

    // Find expired jobs
    const expiredJobs = await db
      .select({ id: jobs.id })
      .from(jobs)
      .where(lt(jobs.expiresAt, new Date()));

    let filesCleaned = 0;
    let dbDeleted = 0;

    for (const job of expiredJobs) {
      // Delete files
      const clipDir = path.join(process.cwd(), "public", "clips", job.id);
      try {
        fs.rmSync(clipDir, { recursive: true, force: true });
        filesCleaned++;
      } catch {
        // ignore
      }

      // Delete from DB
      await db.delete(jobs).where(eq(jobs.id, job.id));
      dbDeleted++;
    }

    return NextResponse.json({
      success: true,
      expiredJobsFound: expiredJobs.length,
      filesCleaned,
      dbDeleted,
    });
  } catch (error) {
    console.error("[Cleanup] Error:", error);
    return NextResponse.json(
      { error: "Cleanup failed" },
      { status: 500 }
    );
  }
}

// Also allow GET for simple health check
export async function GET() {
  try {
    const clipsDir = path.join(process.cwd(), "public", "clips");
    let totalSize = 0;
    let folderCount = 0;

    if (fs.existsSync(clipsDir)) {
      const entries = fs.readdirSync(clipsDir);
      folderCount = entries.length;
      for (const entry of entries) {
        const entryPath = path.join(clipsDir, entry);
        try {
          const stat = fs.statSync(entryPath);
          if (stat.isDirectory()) {
            const files = fs.readdirSync(entryPath);
            for (const f of files) {
              totalSize += fs.statSync(path.join(entryPath, f)).size;
            }
          }
        } catch {
          // ignore
        }
      }
    }

    return NextResponse.json({
      storage: {
        folderCount,
        totalSizeMB: Math.round(totalSize / (1024 * 1024)),
        totalSizeGB: (totalSize / (1024 * 1024 * 1024)).toFixed(2),
      },
    });
  } catch (error) {
    return NextResponse.json({ error: "Failed to get storage stats" }, { status: 500 });
  }
}
